----Building info for Member ----


set serveroutput on;
declare
	
begin
	
	BuildingInfo();
end;
/