drop table trgpaid;
create table trgpaid
(Amountold varchar2(10),AmountNew varchar2(10), updateat date);

drop table trgslry;
create table trgslry
(oldsalary int,Newsalary int, updateat date);


