create or replace package myPackage as

procedure if_male;
procedure if_female;
procedure N_of_Mem;
procedure Booking;
procedure nBooking;




end myPackage;
/
